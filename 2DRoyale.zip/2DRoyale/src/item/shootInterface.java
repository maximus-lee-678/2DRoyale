package item;

interface shootInterface {
	public void shoot();
}
